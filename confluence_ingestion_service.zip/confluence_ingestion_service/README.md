# Confluence Ingestion Service (Simplified)

A minimal FastAPI service for ingesting Confluence pages using Redis for task state.

## Project Structure

```
confluence_ingestion_service/
├── app/
│   ├── main.py              # FastAPI app + all endpoints
│   ├── confluence.py        # Confluence API client
│   ├── tasks.py             # Background task + Redis state
│   └── models.py            # Pydantic models
├── requirements.txt
└── README.md
```

## Quick Start

```bash
# 1. Start Redis
podman run -d --name redis -p 6379:6379 redis:alpine

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the service
uvicorn app.main:app --reload --port 8000
```

## API Endpoints

- `POST /list_pages` - List pages from a root URL (returns tree structure)
- `POST /ingest_pages` - Queue pages for ingestion (returns task_id)
- `GET /task_status/{task_id}` - Poll for task status and progress

## Task Status Messages

During processing, the task provides informative step messages:

```
"Retrieving page content (3/15): Network Configuration"
"Chunking content: Network Configuration"
"Writing chunks to file..."
"Uploading to file service..."
"Complete: Processed 15 pages, 47 chunks"
```
