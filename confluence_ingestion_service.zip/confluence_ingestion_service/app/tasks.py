"""Background task execution with Redis state management."""

from __future__ import annotations
import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any

import redis.asyncio as redis
from langchain_text_splitters import HTMLSemanticPreservingSplitter

from app.models import PageInfo, TaskStatus, TaskStep
from app.confluence import ConfluenceClient


# Redis connection (initialized in main.py)
redis_client: redis.Redis | None = None

# Task state TTL (24 hours)
TASK_TTL = 86400


def get_redis() -> redis.Redis:
    """Get the Redis client."""
    if redis_client is None:
        raise RuntimeError("Redis not initialized")
    return redis_client


async def init_redis(url: str = "redis://localhost:6379/0"):
    """Initialize Redis connection."""
    global redis_client
    redis_client = redis.from_url(url, decode_responses=True)


async def close_redis():
    """Close Redis connection."""
    global redis_client
    if redis_client:
        await redis_client.close()
        redis_client = None


# ============================================================================
# Task State Management
# ============================================================================

def _task_key(task_id: str) -> str:
    """Redis key for task state."""
    return f"task:{task_id}"


async def create_task() -> str:
    """Create a new task and return its ID."""
    task_id = str(uuid.uuid4())
    state = {
        "status": TaskStatus.PENDING.value,
        "step": TaskStep.QUEUED.value,
        "message": "Task queued, waiting to start...",
        "progress": None,
        "result": None,
        "error": None,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await get_redis().setex(_task_key(task_id), TASK_TTL, json.dumps(state))
    return task_id


async def update_task(
    task_id: str,
    status: TaskStatus | None = None,
    step: TaskStep | None = None,
    message: str | None = None,
    progress: dict | None = None,
    result: dict | None = None,
    error: str | None = None,
):
    """Update task state in Redis."""
    r = get_redis()
    key = _task_key(task_id)
    
    # Get current state
    data = await r.get(key)
    state = json.loads(data) if data else {}
    
    # Update fields
    if status is not None:
        state["status"] = status.value
    if step is not None:
        state["step"] = step.value
    if message is not None:
        state["message"] = message
    if progress is not None:
        state["progress"] = progress
    if result is not None:
        state["result"] = result
    if error is not None:
        state["error"] = error
    
    await r.setex(key, TASK_TTL, json.dumps(state))


async def get_task(task_id: str) -> dict | None:
    """Get task state from Redis."""
    data = await get_redis().get(_task_key(task_id))
    return json.loads(data) if data else None


# ============================================================================
# Ingestion Task
# ============================================================================

async def run_ingestion_task(
    task_id: str,
    pages: list[PageInfo],
    confluence_email: str,
    confluence_token: str,
    confluence_base_url: str,
    extra_metadata: dict[str, Any] | None = None,
):
    """
    Run the ingestion task with progress updates.
    
    Steps:
    1. RETRIEVING - Fetch HTML content for each page
    2. CHUNKING - Split content into chunks
    3. WRITING - Write JSONL file
    4. UPLOADING - Upload to file service (if configured)
    """
    total_pages = len(pages)
    all_chunks = []
    failed_pages = []
    
    try:
        # Initialize chunker
        splitter = HTMLSemanticPreservingSplitter(
            headers_to_split_on=[("h1", "H1"), ("h2", "H2"), ("h3", "H3")],
            max_chunk_size=1000,
        )
        
        async with ConfluenceClient(
            email=confluence_email,
            token=confluence_token,
            base_url=confluence_base_url,
        ) as client:
            
            # ----------------------------------------------------------------
            # Step 1: RETRIEVING - Fetch page content
            # ----------------------------------------------------------------
            await update_task(
                task_id,
                status=TaskStatus.PROCESSING,
                step=TaskStep.RETRIEVING,
                message=f"Starting retrieval of {total_pages} pages...",
                progress={"current": 0, "total": total_pages},
            )
            
            page_contents = []
            
            for idx, page in enumerate(pages, 1):
                await update_task(
                    task_id,
                    message=f"Retrieving page ({idx}/{total_pages}): {page.title}",
                    progress={"current": idx, "total": total_pages},
                )
                
                try:
                    html = await client.get_page_body(page.id)
                    page_contents.append((page, html))
                except Exception as e:
                    failed_pages.append({
                        "page_id": page.id,
                        "title": page.title,
                        "error": str(e),
                    })
            
            # ----------------------------------------------------------------
            # Step 2: CHUNKING - Process content
            # ----------------------------------------------------------------
            await update_task(
                task_id,
                step=TaskStep.CHUNKING,
                message=f"Chunking content from {len(page_contents)} pages...",
                progress={"current": 0, "total": len(page_contents)},
            )
            
            for idx, (page, html) in enumerate(page_contents, 1):
                await update_task(
                    task_id,
                    message=f"Chunking ({idx}/{len(page_contents)}): {page.title}",
                    progress={"current": idx, "total": len(page_contents)},
                )
                
                if not html or not html.strip():
                    continue
                
                try:
                    docs = splitter.split_text(html)
                    
                    for chunk_idx, doc in enumerate(docs):
                        content = doc.page_content if hasattr(doc, 'page_content') else str(doc)
                        if not content.strip():
                            continue
                        
                        chunk = {
                            "raw_content": content,
                            "page_id": page.id,
                            "page_url": page.url,
                            "page_title": page.title,
                            "chunk_index": chunk_idx,
                            "total_chunks": len(docs),
                            "metadata": {
                                "source": "confluence",
                                "space_id": page.space_id,
                                **(extra_metadata or {}),
                            },
                        }
                        all_chunks.append(chunk)
                        
                except Exception as e:
                    failed_pages.append({
                        "page_id": page.id,
                        "title": page.title,
                        "error": f"Chunking error: {e}",
                    })
            
            # ----------------------------------------------------------------
            # Step 3: WRITING - Create JSONL
            # ----------------------------------------------------------------
            await update_task(
                task_id,
                step=TaskStep.WRITING,
                message=f"Writing {len(all_chunks)} chunks to JSONL...",
            )
            
            # In a real implementation, write to file and upload
            # For now, we just track the chunks
            jsonl_content = "\n".join(json.dumps(c) for c in all_chunks)
            
            # ----------------------------------------------------------------
            # Step 4: UPLOADING (placeholder)
            # ----------------------------------------------------------------
            await update_task(
                task_id,
                step=TaskStep.UPLOADING,
                message="Upload step (configure FILE_SERVICE_URL to enable)...",
            )
            
            # TODO: Implement actual upload to your file service
            # file_id = await upload_to_file_service(jsonl_content)
            file_id = None
            
            # Small delay to show the step
            await asyncio.sleep(0.5)
        
        # ----------------------------------------------------------------
        # Complete
        # ----------------------------------------------------------------
        pages_processed = total_pages - len(failed_pages)
        
        if failed_pages and pages_processed == 0:
            final_status = TaskStatus.FAILED
        elif failed_pages:
            final_status = TaskStatus.PARTIAL_SUCCESS
        else:
            final_status = TaskStatus.COMPLETED
        
        result = {
            "pages_processed": pages_processed,
            "pages_failed": len(failed_pages),
            "total_chunks": len(all_chunks),
            "failed_pages": failed_pages,
            "file_id": file_id,
        }
        
        await update_task(
            task_id,
            status=final_status,
            step=TaskStep.COMPLETE,
            message=f"Complete: Processed {pages_processed} pages, {len(all_chunks)} chunks"
                    + (f" ({len(failed_pages)} failed)" if failed_pages else ""),
            result=result,
        )
        
    except Exception as e:
        await update_task(
            task_id,
            status=TaskStatus.FAILED,
            step=TaskStep.FAILED,
            message=f"Task failed: {str(e)}",
            error=str(e),
        )
