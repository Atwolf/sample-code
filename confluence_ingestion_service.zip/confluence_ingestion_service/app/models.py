"""Pydantic models for request/response schemas."""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    """Task status values."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL_SUCCESS = "partial_success"


class TaskStep(str, Enum):
    """Current step in the ingestion process."""
    QUEUED = "queued"
    RETRIEVING = "retrieving"
    CHUNKING = "chunking"
    WRITING = "writing"
    UPLOADING = "uploading"
    COMPLETE = "complete"
    FAILED = "failed"


# ============================================================================
# Page Models
# ============================================================================

class PageInfo(BaseModel):
    """Basic page information."""
    id: str
    title: str
    url: str
    space_id: str | None = None
    parent_id: str | None = None


class PageTreeNode(BaseModel):
    """Page with nested children for tree structure."""
    id: str
    title: str
    url: str
    space_id: str | None = None
    parent_id: str | None = None
    children: list[PageTreeNode] = Field(default_factory=list)


# ============================================================================
# Request Models
# ============================================================================

class ListPagesRequest(BaseModel):
    """Request to list pages from a root URL."""
    root_url: str = Field(..., description="Confluence page URL to traverse from")
    confluence_email: str
    confluence_token: str
    confluence_base_url: str | None = None
    max_depth: int | None = None


class IngestPagesRequest(BaseModel):
    """Request to ingest selected pages."""
    pages: list[PageInfo] = Field(..., min_length=1)
    confluence_email: str
    confluence_token: str
    confluence_base_url: str | None = None
    metadata: dict[str, Any] | None = None


# ============================================================================
# Response Models
# ============================================================================

class ListPagesResponse(BaseModel):
    """Response with page tree."""
    root: PageTreeNode
    total_pages: int


class TaskCreatedResponse(BaseModel):
    """Response when task is queued."""
    task_id: str
    status: TaskStatus = TaskStatus.PENDING
    message: str = "Task queued"


class TaskStatusResponse(BaseModel):
    """Response for task status polling."""
    task_id: str
    status: TaskStatus
    step: TaskStep
    message: str = ""
    progress: dict[str, int] | None = None  # {"current": 3, "total": 15}
    result: dict[str, Any] | None = None
    error: str | None = None
