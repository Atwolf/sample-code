"""Confluence Ingestion Service."""
