"""Confluence REST API v2 client."""

from __future__ import annotations
import re
from urllib.parse import urlparse, parse_qs
from typing import Any
import httpx

from app.models import PageInfo, PageTreeNode


class ConfluenceError(Exception):
    """Confluence API error."""
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"Confluence API error {status_code}: {message}")


def parse_confluence_url(url: str) -> tuple[str, str]:
    """
    Extract base URL and page ID from a Confluence URL.
    
    Supports:
    - https://domain.atlassian.net/wiki/spaces/SPACE/pages/123456/Title
    - https://domain.atlassian.net/wiki/pages/viewpage.action?pageId=123456
    """
    parsed = urlparse(url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    
    # Try /wiki/spaces/SPACE/pages/{id} format
    match = re.search(r'/wiki/spaces/[^/]+/pages/(\d+)', parsed.path)
    if match:
        return base_url, match.group(1)
    
    # Try viewpage.action?pageId= format
    if 'viewpage.action' in parsed.path:
        query_params = parse_qs(parsed.query)
        if 'pageId' in query_params:
            return base_url, query_params['pageId'][0]
    
    raise ValueError(f"Could not extract page ID from URL: {url}")


class ConfluenceClient:
    """Simple async Confluence client using REST API v2."""
    
    def __init__(self, email: str, token: str, base_url: str):
        self.base_url = base_url.rstrip('/')
        self.api_base = f"{self.base_url}/wiki/api/v2"
        self._client = httpx.AsyncClient(
            auth=(email, token),
            headers={"Accept": "application/json"},
            timeout=30.0,
        )
    
    async def close(self):
        await self._client.aclose()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self.close()
    
    async def _get(self, endpoint: str, params: dict | None = None) -> dict:
        """Make a GET request to the Confluence API."""
        url = f"{self.api_base}{endpoint}"
        response = await self._client.get(url, params=params)
        
        if response.status_code >= 400:
            raise ConfluenceError(response.status_code, response.text)
        
        return response.json()
    
    async def get_page(self, page_id: str, body_format: str | None = None) -> dict:
        """Get a page by ID."""
        params = {"body-format": body_format} if body_format else None
        return await self._get(f"/pages/{page_id}", params)
    
    async def get_page_body(self, page_id: str) -> str:
        """Get the rendered HTML body of a page."""
        page = await self.get_page(page_id, body_format="view")
        return page.get("body", {}).get("view", {}).get("value", "")
    
    async def get_descendants(self, page_id: str, depth: int | None = None) -> list[dict]:
        """
        Get all descendants of a page using /pages/{id}/descendants.
        Handles pagination automatically.
        """
        all_results = []
        params = {"limit": 250}
        if depth is not None:
            params["depth"] = depth
        
        cursor = None
        while True:
            if cursor:
                params["cursor"] = cursor
            
            response = await self._get(f"/pages/{page_id}/descendants", params)
            all_results.extend(response.get("results", []))
            
            # Check for next page
            next_link = response.get("_links", {}).get("next", "")
            match = re.search(r'cursor=([^&]+)', next_link)
            if match:
                cursor = match.group(1)
            else:
                break
        
        return all_results
    
    async def get_page_tree(self, page_id: str, depth: int | None = None) -> PageTreeNode:
        """Get a page and all its descendants as a tree structure."""
        # Get root page info
        root_page = await self.get_page(page_id)
        
        # Get all descendants
        descendants = await self.get_descendants(page_id, depth)
        
        # Build nodes map
        nodes: dict[str, PageTreeNode] = {}
        
        # Create root node
        root = PageTreeNode(
            id=str(root_page["id"]),
            title=root_page.get("title", ""),
            url=self._build_url(root_page),
            space_id=root_page.get("spaceId"),
            parent_id=root_page.get("parentId"),
        )
        nodes[root.id] = root
        
        # Create nodes for descendants (pages only)
        for desc in descendants:
            if desc.get("type") != "page":
                continue
            
            node = PageTreeNode(
                id=str(desc["id"]),
                title=desc.get("title", ""),
                url=self._build_url(desc),
                space_id=desc.get("spaceId"),
                parent_id=desc.get("parentId"),
            )
            nodes[node.id] = node
        
        # Link children to parents
        for node_id, node in nodes.items():
            if node_id == root.id:
                continue
            parent_id = node.parent_id
            if parent_id in nodes:
                nodes[parent_id].children.append(node)
            else:
                # Direct child of root or orphan
                root.children.append(node)
        
        # Sort children alphabetically
        self._sort_children(root)
        return root
    
    def _sort_children(self, node: PageTreeNode):
        """Recursively sort children by title."""
        node.children.sort(key=lambda x: x.title.lower())
        for child in node.children:
            self._sort_children(child)
    
    def _build_url(self, page_data: dict) -> str:
        """Build web URL for a page."""
        links = page_data.get("_links", {})
        if "webui" in links:
            webui = links["webui"]
            return webui if webui.startswith("http") else f"{self.base_url}{webui}"
        return f"{self.base_url}/wiki/pages/{page_data.get('id', '')}"


def count_pages(node: PageTreeNode) -> int:
    """Count total pages in a tree."""
    return 1 + sum(count_pages(child) for child in node.children)
