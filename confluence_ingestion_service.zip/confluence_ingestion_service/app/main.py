"""FastAPI application - Confluence Ingestion Service."""

import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException, status

from app.models import (
    IngestPagesRequest,
    ListPagesRequest,
    ListPagesResponse,
    PageInfo,
    TaskCreatedResponse,
    TaskStatus,
    TaskStep,
    TaskStatusResponse,
)
from app.confluence import (
    ConfluenceClient,
    ConfluenceError,
    count_pages,
    parse_confluence_url,
)
from app.tasks import (
    close_redis,
    create_task,
    get_task,
    init_redis,
    run_ingestion_task,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup resources."""
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    await init_redis(redis_url)
    print(f"Connected to Redis: {redis_url}")
    yield
    await close_redis()
    print("Disconnected from Redis")


app = FastAPI(
    title="Confluence Ingestion Service",
    description="Ingest Confluence pages into a vector database",
    version="1.0.0",
    lifespan=lifespan,
)


# ============================================================================
# Endpoints
# ============================================================================

@app.get("/health")
async def health():
    """Health check."""
    return {"status": "healthy"}


@app.post("/list_pages", response_model=ListPagesResponse)
async def list_pages(request: ListPagesRequest):
    """
    List all pages under a Confluence root URL.
    
    Returns a tree structure preserving the page hierarchy.
    """
    # Parse URL to get base_url and page_id
    try:
        extracted_base, page_id = parse_confluence_url(request.root_url)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    
    base_url = request.confluence_base_url or extracted_base
    
    try:
        async with ConfluenceClient(
            email=request.confluence_email,
            token=request.confluence_token,
            base_url=base_url,
        ) as client:
            root = await client.get_page_tree(page_id, request.max_depth)
            total = count_pages(root)
            return ListPagesResponse(root=root, total_pages=total)
    
    except ConfluenceError as e:
        if e.status_code == 401:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
        elif e.status_code == 403:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Access denied")
        elif e.status_code == 404:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Page not found")
        else:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, e.message)


@app.post("/ingest_pages", response_model=TaskCreatedResponse, status_code=202)
async def ingest_pages(request: IngestPagesRequest, background_tasks: BackgroundTasks):
    """
    Queue selected pages for ingestion.
    
    Returns a task_id to poll for progress via /task_status/{task_id}.
    """
    # Get base URL
    if request.confluence_base_url:
        base_url = request.confluence_base_url
    else:
        try:
            base_url, _ = parse_confluence_url(request.pages[0].url)
        except (ValueError, IndexError):
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "confluence_base_url required or must be extractable from page URLs"
            )
    
    # Create task
    task_id = await create_task()
    
    # Queue background task
    background_tasks.add_task(
        run_ingestion_task,
        task_id=task_id,
        pages=request.pages,
        confluence_email=request.confluence_email,
        confluence_token=request.confluence_token,
        confluence_base_url=base_url,
        extra_metadata=request.metadata,
    )
    
    return TaskCreatedResponse(
        task_id=task_id,
        status=TaskStatus.PENDING,
        message=f"Ingestion queued for {len(request.pages)} pages",
    )


@app.get("/task_status/{task_id}", response_model=TaskStatusResponse)
async def task_status(task_id: str):
    """
    Get the current status of an ingestion task.
    
    Poll this endpoint to track progress. The `message` field provides
    human-readable status like:
    - "Retrieving page (3/15): Network Configuration"
    - "Chunking (5/15): Security Policies"
    - "Complete: Processed 15 pages, 47 chunks"
    """
    state = await get_task(task_id)
    
    if state is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found")
    
    return TaskStatusResponse(
        task_id=task_id,
        status=TaskStatus(state["status"]),
        step=TaskStep(state["step"]),
        message=state.get("message", ""),
        progress=state.get("progress"),
        result=state.get("result"),
        error=state.get("error"),
    )


# ============================================================================
# Run directly
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
